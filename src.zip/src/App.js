// App.js
import React from 'react';
import { BrowserRouter, Link } from 'react-router-dom';


// CSS
import './styles/common.css';

// Components
import { HeaderLayout, BodyLayout } from './components/layout';


function App() {
  return (
    <BrowserRouter>    
       <HeaderLayout />

      <BodyLayout />

      <div className='app-footer'>
        <ul className='footer-link'>
          <li><Link to="/test1">Feedback</Link></li>
          <li><Link to="/test2">Contact</Link></li>
        </ul>

        <p>© 2024 ShowBok's. All rights reserved.</p>
      </div>
    </BrowserRouter>
  );
}

export default App;