import React from 'react';

const QuickTalk = () => {
  return (
    <div className='talk-wrap'>

    </div>
  );
}

export default QuickTalk;