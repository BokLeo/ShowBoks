export { default as FreeTalk } from "./FreeTalk";
export { default as QuickTalk } from "./QuickTalk";